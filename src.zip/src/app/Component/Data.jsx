export var categories = [
    "Electronics",
    "Men's Fashion",
    "Women's Fashion",
    "Office & Security",
    "Computer",
    "Drone",
    "Gamepad",
    "Mobile",
    "Speaker",
    "All Category",

]

export var products=[
    {
        "id": 1,
        "title": "Xpeed Projector",
        "price": 499,
        "description": "Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/36-2.png",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 2,
        "title": "Apple iPhone 7s",
        "price": 600,
        "description": "Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.",
        "category": "Mobile",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/24-1.png",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 3,
        "title": "Apple iPhone 6s",
        "price": 299,
        "description": "Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.",
        "category": "Mobile",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/21-1.png",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 4,
        "title": "Wireless Microphone",
        "price": 299,
        "description": "Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "projector",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/Cannon-2-Mini-Smart-Bluetooth-1.png",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 5,
        "title": "CC Camera",
        "price": 210,
        
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/08-2.png",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 6,
        "title": "Moving Camera",
        "price": 299,
        
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/07-300x300-1-1.jpg",
        "rating": {
            "rate": 2.1,
            "count": 430
        }
    },
    {
        "id": 7,
        "title": "Unlocked Mobile Phone",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "mobile,projector",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/iphone7-1.png",
        
    },

    {
        "id": 8,
        "title": "Core i7 Laptop",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Laptop, projector",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/iphone7-1.png",
        
    },
    {
        "id": 9,
        "title": "Stereo Headset",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/iphone7-1.png",
        
    },
    {
        "id": 10,
        "title": "Camera Drone",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/camera-drone-1.png",
        
    },
    {
        "id": 11,
        "title": "Holy Stone Drone",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/WIFI-FPV-With-720P-Camera-High-Hold-Foldable-Drones-1.jpg",
        
    },
    {
        "id": 12,
        "title": "LED Projector",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Bluetooth-Smart-Projector-1.jpg",
        
    },
    {
        "id": 13,
        "title": "3D VR Glassr",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/3D-VR-Glass-1.jpg",
        
    },
    {
        "id": 14,
        "title": "Bluetooth Speaker",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/HTB1olbtmlDH8KJj-1.jpg",
        
    },
    {
        "id": 15,
        "title": "Fuers Outdoor",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/05-2.png",
        
    },

    {
        "id": 16,
        "title": "Fuji Film Camera",
        "price": 125,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Original-Fujifilm-Instax-Mini-8-Camera-Film-Camera-1.jpg",
        
    },
    {
        "id": 17,
        "title": "Original Fujifilm Camera",
        "price": 300,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Original-Fujifilm-Camera-Film-Camera-1.jpg",
        
    },
    {
        "id": 18,
        "title": "Original Fujifilm Camera",
        "price": 300,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Original-Fujifilm-Camera-Film-Camera-1.jpg",
        
    }, 
    {
        "id": 19,
        "title": "Professional Drone",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/18-1.png",
        
    },
    {
        "id": 20,
        "title": "VOYO VBOOK V3Pro",
        "price": 210,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Licence-Windows10-13-3-VOYO-VBOOK-V3Pro-Celeron-N3450-Tablet-PC-Laptop-with-8G-RAM-128G-1-1.jpg",
        
    },
    {
        "id": 21,
        "title": "Waterproof Camera",
        "price": 530,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/06-300x300-1-1.jpg",
        
    },
    {
        "id": 22,
        "title": "Wireless Speaker",
        "price": 100,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Computer",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/New-2nd-generation-Smart-Air-1.png",
        
    },
    {
        "id": 23,
        "title": "Bluetooth Gamepad",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/45-1.png",
        
    },
    {
        "id": 24,
        "title": "Bracelet Watch",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/43-1.png",
        
    },
    {
        "id": 25,
        "title": "Camera Drone",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/camera-drone-1.png",
        
    },
    {
        "id": 26,
        "title": "Drone WI FI FPV",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Drone-jjrc-X3-hax-WI-FI-FPV-1-1.jpg",
        
    },
    {
        "id": 27,
        "title": "Drones Helicopter",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/Arasdm-APP-RC-Drones-1.jpg",
        
    },
    {
        "id": 28,
        "title": "Fuers Outdoor",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/05-2.png",
        
    },
    {
        "id": 29,
        "title": "Goldenhour Watch",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/42-1.png",
        
    },
    {
        "id": 30,
        "title": "Headset for Phones",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Drone",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/51-1.png",
        
    },
    {
        "id": 31,
        "title": "Bevigac Gamepad",
        "price": 660,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/47-1.png",
        
    },
    {
        "id": 32,
        "title": "Bluetooth Gamepad",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/47-1.png",
        
    },
    {
        "id": 33,
        "title": "Bracelet Watch",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/43-1.png",
        
    },
    {
        "id": 34,
        "title": "Camera Drone",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/gaming_console-1.png",
        
    },
    {
        "id": 35,
        "title": "Fortnite Controller",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/48-1.png",
        
    },
    {
        "id": 36,
        "title": "Goldenhour Watch",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/42-1.png",
        
    },
    {
        "id": 37,
        "title": "Holy Stone Drone",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/04/WIFI-FPV-With-720P-Camera-High-Hold-Foldable-Drones-1.jpg",
        
    },
    {
        "id": 38,
        "title": "Holy Stone Drone",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/40-1.png",
        
    },
    {
        "id": 39,
        "title": "Mini Game Controller",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/46-1.png",
        
    },
    {
        "id": 40,
        "title": "Professional Drone",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/18-1.png",
        
    },
    {
        "id": 41,
        "title": "Remote Drone",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/19-1.png",
        
    },
    {
        "id": 42,
        "title": "Sony Gamepad",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2013/06/Gamepad-for-Sony-Playstation-3-1.jpg",
        
    },
    {
        "id": 43,
        "title": "Bevigac Gamepad",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/47-1.png",
        
    },
    {
        "id": 44,
        "title": "Metal Body Mobile",
        "price": 200,
        "description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.",
        "category": "Gamepad",
        "image": "https://demo.xpeedstudio.com/marketov2/wp-content/uploads/2018/05/22-1.png",
        
    },
    
    
]