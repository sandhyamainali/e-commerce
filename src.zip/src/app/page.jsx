import React from 'react'
import Home from './Pages/Home'
import Page from './Pages/details/[id]/Page'


function page() {
  return (
    <div>
      
      <Home aa="computer"/>
      <Page/>
    
    </div>
  )
}

export default page
